//
//  JL_OTALib.h
//  JL_OTALib
//
//  Created by EzioChan on 2023/1/29.
//  Copyright © 2023 www.zh-jieli.com. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for JL_OTALib.
FOUNDATION_EXPORT double JL_OTALibVersionNumber;

//! Project version string for JL_OTALib.
FOUNDATION_EXPORT const unsigned char JL_OTALibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JL_OTALib/PublicHeader.h>
#import <JL_OTALib/JL_OTAManager.h>
#import <JL_OTALib/jl_ufw.h>
